#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <set>
#include <stack>

using namespace std;

int main(){
    string w = "ABCD";
    cout << w.substr(0,4) << endl; substr(0,i) :i

                                    substr(i) i:
}